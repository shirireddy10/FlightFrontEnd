import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-showflights',
  templateUrl: './showflights.component.html',
  styleUrls: ['./showflights.component.css']
})
export class ShowflightsComponent implements OnInit {
  bookings: Booking[] | undefined;
  formValue!: FormGroup;
  showAdd: boolean | undefined;
  showBtn: boolean | undefined;
  BookingModelObject: Booking=new Booking;
  booking:any;
  data:any;
   flight_id!: string
  constructor(private formBuilder: FormBuilder,private bookingService :BookingService) { }
getalltickets:any;
  ngOnInit(): void {
    this.bookingService.getalltickets().subscribe((data: Booking[])=>{
      console.log(data);
      this.bookings=data;
  })
  this.formValue = this.formBuilder.group(
    {
      flight_id: [''],
      source: [''],
      destination: [''],
      seats: ['']
    }
  )
  this.getalltickets();
  }


}
