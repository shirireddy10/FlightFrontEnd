import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
 hide=true;
 email = new FormControl('', [Validators.required, Validators.email]);
 formValue!: FormGroup;
 getErrorMessage() {
   if (this.email.hasError('required')) {
     return 'You must enter a value';
   }

   return this.email.hasError('email') ? 'Not a valid email' : '';
 }
  constructor(private formBuilder: FormBuilder,private bookingService :BookingService) { }

  ngOnInit(): void {
  }

}
