import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { AdminService } from 'src/app/service/admin.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
  productlist:Product[]=[]
  constructor(private adminservice:AdminService) { }

  ngOnInit(): void {
    this.adminservice.getproducts().subscribe((res:Product[])=>{
      this.productlist=res;
    })
    
  }

}
