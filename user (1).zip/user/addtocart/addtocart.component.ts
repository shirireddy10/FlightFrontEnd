import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from 'src/app/model/cart';
import { Items } from 'src/app/model/items';
import { Product } from 'src/app/model/product';
import { AdminService } from 'src/app/service/admin.service';

import { CartService } from 'src/app/service/cart.service';
import { MessengerService } from 'src/app/service/messenger.service';

@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
export class AddtocartComponent implements OnInit {
   formValue!:FormGroup
  cartItems:any[]=[];
// cartItems=[]
public products: any=[];
public grandTotal!:number;
quantity: { count: number } = {
  count: 0
};
  
  constructor(private formBuilder: FormBuilder,private msg:MessengerService,private cartservice:CartService,private adminservice:AdminService,private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.cartservice.getProducts().subscribe(res=>{
      this.products=res;
      this.grandTotal=this.cartservice.getTotalPrice();
      
    })
    
  }
 
 
  addToCart(product: Product){
  
    this.cartItems.push({
      productid:product.productid,
      productname:product.productname,
      feature:product.description,
      price:product.price

    })
   
    // this.Items.forEach(item=>{
    //   this.cartTotal+=(item.qty*item.price)
    // })
    
  }
  

  // removeFromCart(item: Items){
  //   this.cartservice.removeFromCart(this.userid, item.id).subscribe();
  //   for(let _item of this.items){
  //     if(_item.id==item.id){
  //       _item.quantity--;
  //       this.adminservice.getProduct(item.id).subscribe(data=>{
  //         _item.price-= data.price;
  //         this.cart.total-= data.price;
  //       });
  //     }
  //   }
  //   console.log(this.cart.items);
    
  // }
}