import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Cart } from 'src/app/model/cart';
import { Items } from 'src/app/model/items';

import { Product } from 'src/app/model/product';
import { AdminService } from 'src/app/service/admin.service';
import { CartService } from 'src/app/service/cart.service';
import { MessengerService } from 'src/app/service/messenger.service';
import { UserService } from 'src/app/service/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {

  @Input()
  productItem!: Product;
  products:Array<Product>=[];

  public items: Items[]=[];

  public product: any;
 
 
  public productList: Product[]=[];
  constructor(private userservice: UserService,private msg:MessengerService,private adminservice:AdminService,private cartservice:CartService) { }

  ngOnInit(): void {
   
    this.userservice.getproduct().subscribe((product:Product[])=>{
      this.productList=product;
      this.productList.forEach((a:any)=>{
        Object.assign(a,{quantity:1,total:a.productprice})
      });
    })
   
  }
 
  addtocart(item:any){
    this.cartservice.addtoCart(item);
  }

 
  
}
