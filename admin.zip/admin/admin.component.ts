import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  admins: Admin[] | undefined;
  formValue!: FormGroup;
  showAdd: boolean | undefined;
  showBtn: boolean | undefined;
  AdminModelObject: Admin=new Admin;
  admin:any;
  data:any;
   flightid!: string
  constructor(private formBuilder: FormBuilder,private adminService :AdminService ) { }

  ngOnInit(): void {
    this.adminService.getBooks().subscribe((data: Admin[])=>{
      console.log(data);
      this.admins=data;
  })
  this.formValue = this.formBuilder.group(
    {
      flightid: [''],
      flightName: [''],
      from_location: [''],
      to_location: ['']
    }
  )
  this.getBooks();
}
clickAddFlight()
{
  this.formValue.reset();
  this.showAdd=true;
  this.showBtn=false;
}

getBooks()
{
  this.adminService.getBooks().subscribe((admin: Admin[])=>
  {
    console.log(admin);
    this.admins= admin;
  });
}
//subscribe
 addFlight() {
 this.AdminModelObject.flightid=this.formValue.value.flightid;
  this.AdminModelObject.flightName= this.formValue.value.flightName;
  this.AdminModelObject.from_location = this.formValue.value.from_location;
 this.AdminModelObject.to_location = this.formValue.value.to_location;

  

this.adminService.postFlight(this.AdminModelObject).subscribe((res:any[]) => {
  console.log(res);
    alert("New record Added");
    this.formValue.reset();
    this.getBooks();
  }
       , err => {
      alert("Error Occured");
      // this.getBooks();
    })
}
//delete
deleteFlight(data:any)
 {
   this.adminService.deleteFlight(data.flightid).subscribe((res:any[])=>{
    console.log(res);
    alert("Record Deleted");
    this.formValue.reset();
    this.getBooks();
    
  })
  if(confirm("delete the record of id " +data.flightid))
  {
    console.log("delete");
  }
}

//edit
onEditFlight(data:any)
{
  
  this.AdminModelObject.flightid = data.flightid;
  this.formValue.controls['flightName'].setValue(data.flightName);
  this.formValue.controls['from_location'].setValue(data.from_location);
  this.formValue.controls['to_location'].setValue(data.to_location);
 
}


updateFlight()
{
  this.AdminModelObject.flightid=this.formValue.value.flightid;
  this.AdminModelObject.flightName= this.formValue.value.flightName;
  this.AdminModelObject.from_location= this.formValue.value.from_location;
  this.AdminModelObject.to_location = this.formValue.value.to_location;
 
  console.log(this.AdminModelObject)

  this.adminService.updateFlight(this.AdminModelObject, this.AdminModelObject.flightid)
  .subscribe((res:any[])=>{
    alert("Record Updated");
    this.getBooks();
  });
}
updateFlight1()
{
  this.AdminModelObject.flightid=this.formValue.value.flightid;
  this.AdminModelObject.flightName= this.formValue.value.flightName;
  this.AdminModelObject.from_location= this.formValue.value.from_location;
  this.AdminModelObject.to_location = this.formValue.value.to_location;
 
  console.log(this.AdminModelObject)

  this.adminService.updateFlight1(this.AdminModelObject, this.AdminModelObject.flightid)
  .subscribe((res:any[])=>{
    alert("Record Added");
    this.getBooks();
  });
}  
  
  

}
  



  



